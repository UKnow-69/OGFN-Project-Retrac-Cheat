#pragma once

namespace GUI {
namespace DX11 {

// --- Initialization ------------------------------------------------

bool Init();
void Destroy();

} // namespace DX11
} // namespace GUI
