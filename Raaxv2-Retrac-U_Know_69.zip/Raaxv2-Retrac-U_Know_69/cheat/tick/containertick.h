#pragma once

namespace Tick {
namespace Container {

// --- Public Tick Functions -----------------------------------------

void TickGameThread();
void TickRenderThread();

} // namespace Container
} // namespace Tick
