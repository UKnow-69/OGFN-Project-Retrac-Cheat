#pragma once

namespace GUI {
namespace MainWindow {

// --- Public Tick Functions -----------------------------------------

void Tick();

// --- Global Variables ----------------------------------------------

extern bool g_WindowOpen;

} // namespace MainWindow
} // namespace GUI
