#pragma once

namespace Features {
namespace Radar {

// --- Public Tick Functions -----------------------------------------

void TickRenderThread();

} // namespace Radar
} // namespace Features
