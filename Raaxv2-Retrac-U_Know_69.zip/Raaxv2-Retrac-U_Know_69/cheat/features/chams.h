#pragma once

namespace Features {
namespace Chams {

// --- Public Functions ----------------------------------------------

void Destroy();
void TickGameThread();

} // namespace Chams
} // namespace Features
